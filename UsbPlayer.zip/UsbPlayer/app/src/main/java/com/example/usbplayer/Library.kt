package com.example.usbplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

data class Track(
    val id: Long, val title: String, val artist: String, val album: String,
    val durationMs: Long, val uri: Uri, val provider: String = "local",
    val genre: String = "", val year: Int = 0, val trackNo: Int = 0, val albumArtist: String = ""
)

fun Track.albumKey() = "${album.ifEmpty { "Без альбома" }}\u0000${albumArtist.ifEmpty { artist }}"

object Library {
    fun load(ctx: Context): List<Track> {
        val m = MediaStore.Audio.Media
        val cols = mutableListOf(m._ID, m.TITLE, m.ARTIST, m.ALBUM, m.DURATION, m.YEAR, m.TRACK)
        val tagsExtra = Build.VERSION.SDK_INT >= 30
        if (tagsExtra) { cols += m.ALBUM_ARTIST; cols += m.GENRE }
        val out = mutableListOf<Track>()
        ctx.contentResolver.query(
            m.EXTERNAL_CONTENT_URI, cols.toTypedArray(), "${m.IS_MUSIC} != 0", null,
            "${m.TITLE} COLLATE NOCASE"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out += Track(
                    id, c.getString(1) ?: "?", c.getString(2) ?: "Unknown", c.getString(3) ?: "",
                    c.getLong(4), ContentUris.withAppendedId(m.EXTERNAL_CONTENT_URI, id),
                    year = c.getInt(5), trackNo = c.getInt(6),
                    albumArtist = if (tagsExtra) c.getString(7) ?: "" else "",
                    genre = if (tagsExtra) c.getString(8) ?: "" else ""
                )
            }
        }
        return out
    }
}
