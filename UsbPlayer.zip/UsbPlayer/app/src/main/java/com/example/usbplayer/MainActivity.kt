package com.example.usbplayer

import android.Manifest
import android.content.ComponentName
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var tracks by mutableStateOf<List<Track>>(emptyList())
    private lateinit var playlists: Playlists

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tracks = Library.load(this)
    }
    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { playOne(it) } }
    private val importEq = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val text = contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() }.orEmpty()
            val name = it.lastPathSegment?.substringAfterLast('/')?.removeSuffix(".txt") ?: "AutoEQ"
            if (Eq.load(text, name)) AppState.reapply?.invoke() else AppState.message = "Не удалось разобрать профиль AutoEQ"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        playlists = Playlists(this)
        val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        perms.launch(arrayOf(audioPerm, Manifest.permission.POST_NOTIFICATIONS))

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        f.addListener({ controller = f.get() }, ContextCompat.getMainExecutor(this))
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { Screen() } } }
    }

    @Composable
    fun TrackRow(t: Track, action: String?, onAction: () -> Unit, onPlay: () -> Unit) {
        ListItem(
            headlineContent = { Text((if (t.trackNo > 0) "${t.trackNo % 1000}. " else "") + t.title, maxLines = 1) },
            supportingContent = {
                Text(listOfNotNull(t.artist, t.album.ifEmpty { null }, t.genre.ifEmpty { null },
                    t.year.takeIf { it > 0 }?.toString()).joinToString(" · "), maxLines = 1)
            },
            trailingContent = if (action != null) { { TextButton(onAction) { Text(action) } } } else null,
            modifier = Modifier.clickable(onClick = onPlay))
    }

    @Composable
    fun Screen() {
        val c = controller
        val scope = rememberCoroutineScope()
        var playing by remember { mutableStateOf(false) }
        var pos by remember { mutableLongStateOf(0L) }
        var dur by remember { mutableLongStateOf(1L) }
        var title by remember { mutableStateOf("") }
        var tab by remember { mutableIntStateOf(0) }
        var filter by remember { mutableStateOf("") }
        var openAlbum by remember { mutableStateOf<String?>(null) }
        var openPl by remember { mutableStateOf<String?>(null) }
        var newPl by remember { mutableStateOf("") }
        var plVersion by remember { mutableIntStateOf(0) }
        var addTrack by remember { mutableStateOf<Track?>(null) }
        var loggedIn by remember { mutableStateOf(Providers.qobuz.token != null) }
        var email by remember { mutableStateOf("") }
        var pass by remember { mutableStateOf("") }
        var query by remember { mutableStateOf("") }
        var remote by remember { mutableStateOf<List<Track>>(emptyList()) }
        var error by remember { mutableStateOf<String?>(null) }

        LaunchedEffect(c) {
            while (true) {
                c?.let { playing = it.isPlaying; pos = it.currentPosition
                    dur = it.duration.coerceAtLeast(1L); title = it.mediaMetadata.title?.toString() ?: "" }
                delay(500)
            }
        }
        val plNames = remember(plVersion) { playlists.names() }
        val albums = remember(tracks) { tracks.groupBy { it.albumKey() }.toList().sortedBy { it.first } }

        addTrack?.let { t ->
            AlertDialog(onDismissRequest = { addTrack = null }, confirmButton = {},
                title = { Text("В плейлист") },
                text = {
                    Column {
                        if (plNames.isEmpty()) Text("Сначала создайте плейлист во вкладке «Плейлисты»")
                        plNames.forEach { n -> TextButton({ playlists.add(n, t.id); plVersion++; addTrack = null }) { Text(n) } }
                    }
                })
        }

        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Column(Modifier.padding(16.dp)) {
                Text(AppState.dacName?.let { "USB DAC: $it" } ?: "USB DAC не найден (системный вывод)",
                    style = MaterialTheme.typography.titleMedium)
                Text(if (AppState.bitPerfectActive) "Bit-perfect: активен" else
                    if (Build.VERSION.SDK_INT < 34) "Bit-perfect: нужен Android 14+" else "Bit-perfect: выключен",
                    style = MaterialTheme.typography.bodySmall)
                if (AppState.formatInfo.isNotEmpty()) Text(AppState.formatInfo, style = MaterialTheme.typography.bodySmall)
                AppState.message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (Eq.active) "Bit-perfect (выкл. из-за EQ)" else "Bit-perfect", Modifier.weight(1f))
                    Switch(AppState.bitPerfectWanted, { AppState.bitPerfectWanted = it; AppState.reapply?.invoke() })
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Треки", "Альбомы", "Плейлисты", "Qobuz", "EQ").forEachIndexed { i, n ->
                    FilterChip(tab == i, { tab = i; openAlbum = null; openPl = null }, { Text(n) })
                }
            }

            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> Column {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(filter, { filter = it }, label = { Text("Поиск по тегам") },
                                singleLine = true, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            Button({ openFile.launch(arrayOf("*/*")) }) { Text("Файл") }
                        }
                        val list = tracks.filter {
                            filter.isBlank() || listOf(it.title, it.artist, it.album, it.genre).any { s -> s.contains(filter, true) }
                        }
                        LazyColumn { itemsIndexed(list) { i, t -> TrackRow(t, "＋", { addTrack = t }) { play(list, i) } } }
                    }
                    1 -> if (openAlbum == null) {
                        LazyColumn {
                            items(albums) { (key, ts) ->
                                val (alb, art) = key.split('\u0000')
                                ListItem(
                                    headlineContent = { Text(alb, maxLines = 1) },
                                    supportingContent = { Text("$art · ${ts.size} тр." + (ts.first().year.takeIf { it > 0 }?.let { " · $it" } ?: ""), maxLines = 1) },
                                    modifier = Modifier.clickable { openAlbum = key })
                            }
                        }
                    } else Column {
                        TextButton({ openAlbum = null }) { Text("← Альбомы") }
                        val list = tracks.filter { it.albumKey() == openAlbum }.sortedBy { it.trackNo }
                        LazyColumn { itemsIndexed(list) { i, t -> TrackRow(t, "＋", { addTrack = t }) { play(list, i) } } }
                    }
                    2 -> if (openPl == null) Column {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(newPl, { newPl = it }, label = { Text("Новый плейлист") }, singleLine = true, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            Button({ playlists.create(newPl); newPl = ""; plVersion++ }) { Text("Создать") }
                        }
                        LazyColumn {
                            items(plNames) { n ->
                                ListItem(
                                    headlineContent = { Text(n) },
                                    supportingContent = { Text("${playlists.get(n).size} тр.") },
                                    trailingContent = { TextButton({ playlists.delete(n); plVersion++ }) { Text("Удалить") } },
                                    modifier = Modifier.clickable { openPl = n })
                            }
                        }
                    } else Column {
                        TextButton({ openPl = null }) { Text("← Плейлисты") }
                        val name = openPl!!
                        val list = playlists.get(name).mapNotNull { id -> tracks.find { it.id == id } }
                        LazyColumn { itemsIndexed(list) { i, t -> TrackRow(t, "✕", { playlists.remove(name, t.id); plVersion++ }) { play(list, i) } } }
                    }
                    3 -> Column {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            when {
                                !Providers.qobuz.configured -> Text("Впишите app_id и app_secret от Qobuz в Credentials.kt")
                                !loggedIn -> {
                                    OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(pass, { pass = it }, label = { Text("Пароль") }, singleLine = true,
                                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                                    Button({ scope.launch {
                                        error = null
                                        runCatching { withContext(Dispatchers.IO) { Providers.qobuz.login(email, pass) } }
                                            .onSuccess { loggedIn = it; if (!it) error = "Не удалось войти" }
                                            .onFailure { error = it.message }
                                    } }) { Text("Войти") }
                                }
                                else -> Row(verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(query, { query = it }, label = { Text("Поиск треков") }, singleLine = true, modifier = Modifier.weight(1f))
                                    Spacer(Modifier.width(8.dp))
                                    Button({ scope.launch {
                                        error = null
                                        runCatching { withContext(Dispatchers.IO) { Providers.qobuz.search(query) } }
                                            .onSuccess { remote = it }.onFailure { error = it.message }
                                    } }) { Text("Найти") }
                                }
                            }
                            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        }
                        LazyColumn { itemsIndexed(remote) { i, t -> TrackRow(t, null, {}) { play(remote, i) } } }
                    }
                    else -> Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Эквалайзер (AutoEQ)", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                            Switch(Eq.enabled, { Eq.enabled = it; AppState.reapply?.invoke() ?: Eq.apply() })
                        }
                        Text(Eq.name ?: "Профиль не загружен")
                        Text("Preamp ${Eq.preamp} dB · фильтров: ${Eq.filters.size}", style = MaterialTheme.typography.bodySmall)
                        Button({ importEq.launch(arrayOf("*/*")) }) { Text("Импорт ParametricEQ.txt") }
                        Text("EQ работает в обычном режиме: при его включении bit-perfect отключается. На DSD EQ не применяется.",
                            style = MaterialTheme.typography.bodySmall)
                        Eq.filters.forEach { Text("${it.type}  ${it.fc.toInt()} Hz  ${it.gain} dB  Q ${it.q}", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }

            Column(Modifier.padding(16.dp)) {
                Text(title, maxLines = 1, style = MaterialTheme.typography.titleSmall)
                Slider(pos.toFloat(), { c?.seekTo(it.toLong()) }, valueRange = 0f..dur.toFloat())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    TextButton({ c?.seekToPreviousMediaItem() }) { Text("⏮") }
                    Button({ if (playing) c?.pause() else c?.play() }) { Text(if (playing) "Пауза" else "Играть") }
                    TextButton({ c?.seekToNextMediaItem() }) { Text("⏭") }
                }
            }
        }
    }

    private fun item(t: Track) = MediaItem.Builder().setMediaId("${t.provider}:${t.id}")
        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(t.uri).build())
        .setMediaMetadata(MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album).build())
        .build()

    private fun play(list: List<Track>, index: Int) {
        val c = controller ?: return
        AppState.message = null
        c.setMediaItems(list.map(::item), index, 0L); c.prepare(); c.play()
    }

    /** Одиночный файл из проводника (в т.ч. DSF/DFF, которые MediaStore может не индексировать). */
    private fun playOne(uri: Uri) = play(listOf(Track(0, uri.lastPathSegment?.substringAfterLast('/') ?: "Файл", "", "", 0, uri)), 0)
}
