package com.example.usbplayer

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object AppState {
    var dacName by mutableStateOf<String?>(null)
    var bitPerfectWanted by mutableStateOf(true)
    var bitPerfectActive by mutableStateOf(false)
    var formatInfo by mutableStateOf("")
    var message by mutableStateOf<String?>(null)
    var bpInfo by mutableStateOf("")
    var reapply: (() -> Unit)? = null
}

object UsbDac {
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

    fun find(ctx: Context): AudioDeviceInfo? =
        ctx.getSystemService(AudioManager::class.java)
            .getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .firstOrNull { it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET }

    class BpResult(val ok: Boolean, val info: String)

    private fun enc(e: Int) = when (e) {
        android.media.AudioFormat.ENCODING_PCM_16BIT -> "PCM16"
        android.media.AudioFormat.ENCODING_PCM_FLOAT -> "Float"
        android.media.AudioFormat.ENCODING_PCM_24BIT_PACKED -> "PCM24"
        android.media.AudioFormat.ENCODING_PCM_32BIT -> "PCM32"
        else -> "enc$e"
    }

    /** exact = true (DSD/DoP): допустима только точно совпадающая частота. */
    fun setBitPerfect(ctx: Context, dev: AudioDeviceInfo, wantRate: Int?, on: Boolean, exact: Boolean = false): BpResult {
        if (Build.VERSION.SDK_INT < 34) return BpResult(false, "нужен Android 14+")
        val am = ctx.getSystemService(AudioManager::class.java)
        return try {
            if (!on) {
                am.clearPreferredMixerAttributes(attrs, dev)
                BpResult(false, "выключен переключателем")
            } else {
                val all = am.getSupportedMixerAttributes(dev)
                val modes = all.filter { it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT }
                if (modes.isEmpty()) {
                    BpResult(false, "прошивка не даёт bit-perfect для этого ЦАПа (режимов всего: ${all.size}, bit-perfect: 0)")
                } else {
                    val order = listOf(android.media.AudioFormat.ENCODING_PCM_16BIT, android.media.AudioFormat.ENCODING_PCM_FLOAT,
                        android.media.AudioFormat.ENCODING_PCM_32BIT, android.media.AudioFormat.ENCODING_PCM_24BIT_PACKED)
                    val sameRate = modes.filter { it.format.sampleRate == wantRate }
                        .sortedBy { order.indexOf(it.format.encoding).let { i -> if (i < 0) 99 else i } }
                    val pick = sameRate.firstOrNull() ?: if (exact) null else modes.maxByOrNull { it.format.sampleRate }
                    if (pick == null) BpResult(false, "нет режима ${wantRate} Гц; есть: " +
                        modes.joinToString { "${it.format.sampleRate}/${enc(it.format.encoding)}" })
                    else {
                        val ok = am.setPreferredMixerAttributes(attrs, dev, pick)
                        BpResult(ok, "${pick.format.sampleRate} Гц ${enc(pick.format.encoding)}" +
                            if (ok) "" else " — система отклонила запрос")
                    }
                }
            }
        } catch (e: Exception) { BpResult(false, "ошибка ${e.javaClass.simpleName}: ${e.message}") }
    }
}
