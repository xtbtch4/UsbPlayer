package com.example.usbplayer

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object AppState {
    var dacName by mutableStateOf<String?>(null)
    var bitPerfectWanted by mutableStateOf(true)
    var bitPerfectActive by mutableStateOf(false)
    var formatInfo by mutableStateOf("")
    var message by mutableStateOf<String?>(null)
    var reapply: (() -> Unit)? = null
}

object UsbDac {
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

    fun find(ctx: Context): AudioDeviceInfo? =
        ctx.getSystemService(AudioManager::class.java)
            .getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .firstOrNull { it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET }

    /** exact = true (DSD/DoP): допустима только точно совпадающая частота. */
    fun setBitPerfect(ctx: Context, dev: AudioDeviceInfo, wantRate: Int?, on: Boolean, exact: Boolean = false): Boolean {
        if (Build.VERSION.SDK_INT < 34) return false
        val am = ctx.getSystemService(AudioManager::class.java)
        if (!on) { am.clearPreferredMixerAttributes(attrs, dev); return false }
        val modes = am.getSupportedMixerAttributes(dev)
            .filter { it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT }
        val pick = modes.firstOrNull { it.format.sampleRate == wantRate }
            ?: (if (exact) null else modes.maxByOrNull { it.format.sampleRate }) ?: return false
        return am.setPreferredMixerAttributes(attrs, dev, pick)
    }
}
